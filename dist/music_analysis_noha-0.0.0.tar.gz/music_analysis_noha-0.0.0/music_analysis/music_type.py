# MY FIRST FUNCTION
# we have create our function guitar_loop() inside the module music_type.py
# the function guitar_loop has one argument called file_input and returns a loop of 3 times
def guitar_loops(file_input):
    # create loop
    file_input = file_input * 3
    return file_input


